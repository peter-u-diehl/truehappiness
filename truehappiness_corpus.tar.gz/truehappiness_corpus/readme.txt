__Instructions__
To obtain a copy of the TrueHappiness training and testing splits:

1) download the original dataset from PLoS ONE to this directory. E.g. by visiting
http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0026752#pone.0026752.s001
and clicking Download > Download this file

2) run ./prepare_dataset.sh


__To cite this work__
Diehl, Peter U., Bruno U. Pedroni, Andrew Cassidy, Paul Merolla, Emre Neftci, and Guido Zarrella. "TrueHappiness: Neuromorphic Emotion Recognition on TrueNorth." Proceedings of Neural Networks (IJCNN), The 2016 International Joint Conference on. IEEE, 2016.


__To cite Hedonometer__
Dodds PS, Harris KD, Kloumann IM, Bliss CA, Danforth CM (2011) Temporal Patterns of Happiness and Information in a Global Social Network: Hedonometrics and Twitter. PLoS ONE 6(12): e26752. doi:10.1371/journal.pone.0026752


NOTICE: This software was produced for the U. S. Government
   under Contract No. W15P7T-10-C-F600, and is
   subject to the Rights in Noncommercial Computer Software
   and Noncommercial Computer Software Documentation
   Clause 252.227-7014 (JUN 1995)

(C) 2016 The MITRE Corporation. All Rights Reserved.
Approved for Public Release; Distribution Unlimited. Case Number 16-0162
