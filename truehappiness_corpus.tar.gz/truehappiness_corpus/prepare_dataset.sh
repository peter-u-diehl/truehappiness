#!/bin/bash

if [ ! -f ./Data_Set_S1.txt ]; then
    echo "***** ERROR *****"
    echo "Please download the Hedonometer dataset ('Data_Set_S1.txt') to this directory."
    echo "See: http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0026752#pone.0026752.s001"
    echo "**** Exiting ****"
    exit
fi

echo "creating hedonometer_train.txt"
hedwords=$(cat train_words.txt | perl -nle 'print "^$_\\t"'); tail -n+5 Data_Set_S1.txt | grep --line-buffered -E "${hedwords}" | cut -f 1,3 > hedonometer_train.txt
echo "creating hedonometer_test.txt"
hedwords=$(cat test_words.txt | perl -nle 'print "^$_\\t"'); tail -n+5 Data_Set_S1.txt | grep --line-buffered -E "${hedwords}" | cut -f 1,3 > hedonometer_test.txt
echo "Done."
